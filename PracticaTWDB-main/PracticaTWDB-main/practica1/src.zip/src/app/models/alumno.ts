export class Alumno {
    id=0
    nombre!: string
    grado!: string
    edad!: number
}
